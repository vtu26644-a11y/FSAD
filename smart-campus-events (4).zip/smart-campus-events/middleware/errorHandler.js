// middleware/errorHandler.js — Global error handling (@ControllerAdvice equivalent)

const errorHandler = (err, req, res, next) => {
  console.error(`[ERROR] ${new Date().toISOString()} — ${req.method} ${req.url}`);
  console.error(err.stack || err.message);

  // Validation errors from express-validator
  if (err.type === 'validation') {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: err.errors,
    });
  }

  // MySQL duplicate entry
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({
      success: false,
      message: 'Duplicate entry. You may have already registered for this event.',
    });
  }

  // MySQL foreign key violation
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({
      success: false,
      message: 'Referenced record does not exist.',
    });
  }

  // 404 Not Found
  if (err.status === 404) {
    return res.status(404).json({
      success: false,
      message: err.message || 'Resource not found.',
    });
  }

  // Default 500
  return res.status(500).json({
    success: false,
    message: 'An internal server error occurred. Please try again later.',
  });
};

// 404 handler for unknown routes
const notFound = (req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.method} ${req.url} not found.`,
  });
};

module.exports = { errorHandler, notFound };
