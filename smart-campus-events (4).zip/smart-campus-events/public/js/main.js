// main.js — Student portal: browse events + register
'use strict';

let currentPage  = 1;
let currentEvent = null;

// ── On Load ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadMeta();
  loadEvents(1);
  loadHeroStats();

  // Debounced search on type
  document.getElementById('filter-search').addEventListener('input',
    debounce(() => loadEvents(1), 450)
  );
});

// ── Load filter meta (departments) ───────────────────────────
async function loadMeta() {
  try {
    const { data } = await apiFetch('/api/events/meta');
    if (!data.success) return;
    const sel = document.getElementById('filter-dept');
    data.departments.forEach(dept => {
      const opt = document.createElement('option');
      opt.value = dept; opt.textContent = dept;
      sel.appendChild(opt);
    });
  } catch {}
}

// ── Load Hero Stats ───────────────────────────────────────────
async function loadHeroStats() {
  try {
    const { data } = await apiFetch('/api/events?limit=1&upcoming=true');
    if (data.success) {
      animateNumber('stat-events', data.pagination.total);
    }
    const { data: d2 } = await apiFetch('/api/events/meta');
    if (d2.success) {
      animateNumber('stat-depts', d2.departments.length);
    }
    // rough total registrations via stats (admin endpoint might 401 — use fallback)
    document.getElementById('stat-registrations').textContent = '200+';
  } catch {}
}

function animateNumber(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  let current = 0;
  const step = Math.ceil(target / 30);
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current;
    if (current >= target) clearInterval(timer);
  }, 40);
}

// ── Load Events ───────────────────────────────────────────────
async function loadEvents(page = 1) {
  currentPage = page;
  const grid = document.getElementById('events-grid');
  grid.innerHTML = Array(6).fill(`
    <div class="skeleton-card">
      <div class="skeleton" style="height:8px;margin-bottom:18px"></div>
      <div class="skeleton" style="height:16px;width:60%;margin-bottom:10px"></div>
      <div class="skeleton" style="height:16px;width:90%;margin-bottom:6px"></div>
      <div class="skeleton" style="height:16px;width:75%;margin-bottom:20px"></div>
      <div class="skeleton" style="height:80px;margin-bottom:16px;border-radius:8px"></div>
      <div class="skeleton" style="height:36px"></div>
    </div>`).join('');

  const params = new URLSearchParams({
    page,
    limit:    9,
    upcoming: 'true',
  });

  const search = document.getElementById('filter-search').value.trim();
  const type   = document.getElementById('filter-type').value;
  const dept   = document.getElementById('filter-dept').value;
  const date   = document.getElementById('filter-date').value;

  if (search) params.set('search', search);
  if (type)   params.set('type', type);
  if (dept)   params.set('department', dept);
  if (date)   params.set('date', date);

  try {
    const { data } = await apiFetch(`/api/events?${params}`);
    if (!data.success) { showError(grid); return; }

    const { data: events, pagination } = data;

    document.getElementById('results-count').textContent =
      pagination.total === 0
        ? 'No events match your filters.'
        : `Showing ${events.length} of ${pagination.total} event${pagination.total !== 1 ? 's' : ''}`;

    grid.innerHTML = events.length ? events.map(renderEventCard).join('') : `
      <div class="empty-state" style="grid-column:1/-1">
        <div class="empty-state-icon">🔍</div>
        <h3>No events found</h3>
        <p>Try adjusting your filters or search term.</p>
        <button class="btn btn-ghost mt-24" onclick="clearFilters()">Clear Filters</button>
      </div>`;

    renderPagination(pagination);
  } catch (err) {
    showError(grid);
  }
}

// ── Render Event Card ─────────────────────────────────────────
function renderEventCard(ev) {
  const pct       = Math.round((ev.registered_count / ev.max_seats) * 100);
  const fillClass = seatFillClass(pct);
  const isFull    = pct >= 100;
  const color     = typeColor(ev.event_type);

  return `
  <div class="event-card type-${ev.event_type}">
    <div class="event-card-banner"></div>
    <div class="event-card-body">
      <div class="event-card-meta">
        <span class="badge badge-type" style="background:${color}22;color:${color}">
          ${ev.event_type.charAt(0).toUpperCase() + ev.event_type.slice(1)}
        </span>
        <span class="badge badge-dept">${ev.department}</span>
        ${isFull
          ? '<span class="badge badge-full">Fully Booked</span>'
          : ev.seats_available <= 10
          ? `<span class="badge badge-warning">${ev.seats_available} seats left</span>`
          : ''}
      </div>
      <div class="event-card-title">${escHtml(ev.title)}</div>
      <div class="event-card-desc">${escHtml(ev.description)}</div>
      <div class="event-card-details">
        <div class="event-detail-row">
          <span class="event-detail-icon">📅</span>
          <span>${formatDate(ev.event_date)}</span>
        </div>
        <div class="event-detail-row">
          <span class="event-detail-icon">🕐</span>
          <span>${formatTime(ev.event_time)}</span>
        </div>
        <div class="event-detail-row">
          <span class="event-detail-icon">📍</span>
          <span>${escHtml(ev.venue)}</span>
        </div>
        ${ev.speaker_name ? `
        <div class="event-detail-row">
          <span class="event-detail-icon">🎤</span>
          <span>${escHtml(ev.speaker_name)}</span>
        </div>` : ''}
      </div>
      <div class="event-card-footer">
        <div class="seats-bar-wrap">
          <div class="seats-label">
            <span>${ev.registered_count} registered</span>
            <span>${isFull ? 'Full' : ev.seats_available + ' available'}</span>
          </div>
          <div class="seats-bar">
            <div class="seats-bar-fill ${fillClass}" style="width:${Math.min(pct,100)}%"></div>
          </div>
        </div>
        <button class="btn btn-primary btn-sm" style="margin-left:12px;flex-shrink:0"
          ${isFull ? 'disabled style="opacity:.5;cursor:not-allowed;margin-left:12px;flex-shrink:0"' : ''}
          onclick="openRegistrationModal(${ev.id})">
          ${isFull ? 'Full' : '<i class="fa fa-plus"></i> Register'}
        </button>
      </div>
    </div>
  </div>`;
}

function escHtml(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function showError(grid) {
  grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
    <div class="empty-state-icon">⚠️</div>
    <h3>Failed to load events</h3>
    <p>Please check your connection and try again.</p>
    <button class="btn btn-forest mt-24" onclick="loadEvents(1)">Retry</button>
  </div>`;
}

// ── Pagination ────────────────────────────────────────────────
function renderPagination(pagination) {
  const { page, totalPages } = pagination;
  const container = document.getElementById('pagination');
  if (totalPages <= 1) { container.innerHTML = ''; return; }

  let html = `<button class="page-btn" onclick="loadEvents(${page - 1})" ${page <= 1 ? 'disabled' : ''}>‹</button>`;

  for (let i = 1; i <= totalPages; i++) {
    if (totalPages > 7) {
      if (i > 2 && i < totalPages - 1 && Math.abs(i - page) > 1) {
        if (i === 3 || i === totalPages - 2) html += `<span style="padding:0 4px;color:var(--text-muted)">…</span>`;
        continue;
      }
    }
    html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="loadEvents(${i})">${i}</button>`;
  }

  html += `<button class="page-btn" onclick="loadEvents(${page + 1})" ${page >= totalPages ? 'disabled' : ''}>›</button>`;
  container.innerHTML = html;
}

// ── Clear Filters ─────────────────────────────────────────────
function clearFilters() {
  document.getElementById('filter-search').value = '';
  document.getElementById('filter-type').value   = '';
  document.getElementById('filter-dept').value   = '';
  document.getElementById('filter-date').value   = '';
  loadEvents(1);
}

// ── Registration Modal ────────────────────────────────────────
async function openRegistrationModal(eventId) {
  try {
    const { data } = await apiFetch(`/api/events/${eventId}`);
    if (!data.success) { showToast('Event not found.', 'error'); return; }

    currentEvent = data.data;
    const ev     = currentEvent;

    document.getElementById('reg-event-id').value = ev.id;
    document.getElementById('modal-title').textContent = 'Register for Event';
    document.getElementById('modal-event-info').innerHTML = `
      <div style="font-family:var(--font-head);font-size:1rem;font-weight:700;margin-bottom:6px">${escHtml(ev.title)}</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:.82rem;color:var(--text-secondary)">
        <span>📅 ${formatDate(ev.event_date)}</span>
        <span>🕐 ${formatTime(ev.event_time)}</span>
        <span>📍 ${escHtml(ev.venue)}</span>
        <span>💺 ${ev.seats_available} seats available</span>
      </div>`;

    // Clear previous errors
    ['name','student-id','email','dept','year','phone'].forEach(f => {
      const el = document.getElementById(`err-${f}`);
      if (el) { el.classList.add('hidden'); }
      const inp = document.getElementById(`reg-${f}`);
      if (inp) { inp.value = ''; inp.classList.remove('error'); }
    });

    openModal('reg-modal');
  } catch (err) {
    showToast('Failed to load event details.', 'error');
  }
}

function closeModal() { closeModalById('reg-modal'); }

// ── Form Validation ───────────────────────────────────────────
function showFieldError(fieldId, errId, message) {
  const inp = document.getElementById(fieldId);
  const err = document.getElementById(errId);
  if (inp) inp.classList.add('error');
  if (err) {
    err.classList.remove('hidden');
    err.querySelector('span') && (err.querySelector('span').textContent = message);
    if (!err.querySelector('span')) err.textContent = message;
  }
}

function clearFieldError(fieldId, errId) {
  const inp = document.getElementById(fieldId);
  const err = document.getElementById(errId);
  if (inp) inp.classList.remove('error');
  if (err) err.classList.add('hidden');
}

function validateRegistrationForm() {
  let valid = true;
  ['name','student-id','email','dept','year','phone'].forEach(f => clearFieldError(`reg-${f}`, `err-${f}`));

  const name    = document.getElementById('reg-name').value.trim();
  const stId    = document.getElementById('reg-student-id').value.trim();
  const email   = document.getElementById('reg-email').value.trim();
  const dept    = document.getElementById('reg-dept').value;
  const year    = document.getElementById('reg-year').value;
  const phone   = document.getElementById('reg-phone').value.trim();

  if (!name || name.length < 2) {
    showFieldError('reg-name', 'err-name', 'Full name must be at least 2 characters.');
    valid = false;
  }
  if (!stId) {
    showFieldError('reg-student-id', 'err-student-id', 'Student ID is required.');
    valid = false;
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showFieldError('reg-email', 'err-email', 'Enter a valid email address.');
    valid = false;
  }
  if (!dept) {
    showFieldError('reg-dept', 'err-dept', 'Please select your department.');
    valid = false;
  }
  if (!year) {
    showFieldError('reg-year', 'err-year', 'Please select your year of study.');
    valid = false;
  }
  if (!phone || !/^[6-9]\d{9}$/.test(phone)) {
    showFieldError('reg-phone', 'err-phone', 'Enter a valid 10-digit mobile number starting with 6–9.');
    valid = false;
  }
  return valid;
}

// ── Submit Registration ───────────────────────────────────────
async function submitRegistration() {
  if (!validateRegistrationForm()) return;

  const btn = document.getElementById('reg-submit-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Registering…';

  const payload = {
    event_id:      parseInt(document.getElementById('reg-event-id').value),
    student_name:  document.getElementById('reg-name').value.trim(),
    student_id:    document.getElementById('reg-student-id').value.trim(),
    student_email: document.getElementById('reg-email').value.trim(),
    department:    document.getElementById('reg-dept').value,
    year_of_study: parseInt(document.getElementById('reg-year').value),
    phone:         document.getElementById('reg-phone').value.trim(),
  };

  try {
    const { res, data } = await apiFetch('/api/registrations', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });

    if (data.success) {
      closeModal();
      showToast(data.message, 'success', 5000);
      loadEvents(currentPage); // refresh seat count
    } else {
      const msg = data.errors ? data.errors[0].msg : data.message;
      showToast(msg, 'error');
    }
  } catch {
    showToast('Registration failed. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-check"></i> Confirm Registration';
  }
}
