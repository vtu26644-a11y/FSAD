// my-events.js — Student: view registered events + submit feedback
'use strict';

let allRegistrations = [];
let currentEmail     = '';
let feedbackRating   = 0;

// ── Lookup ────────────────────────────────────────────────────
async function lookupRegistrations() {
  const email = document.getElementById('lookup-email').value.trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showToast('Please enter a valid email address.', 'error');
    return;
  }
  currentEmail = email;

  document.getElementById('my-events-placeholder').style.display = 'none';
  document.getElementById('my-events-empty').classList.add('hidden');
  document.getElementById('my-events-results').style.display = 'none';

  try {
    const { data } = await apiFetch(`/api/registrations/student/${encodeURIComponent(email)}`);
    if (!data.success) { showToast('Failed to fetch registrations.', 'error'); return; }

    allRegistrations = data.data;

    if (!allRegistrations.length) {
      document.getElementById('my-events-empty').classList.remove('hidden');
      return;
    }

    document.getElementById('my-events-count').textContent =
      `${allRegistrations.length} event${allRegistrations.length !== 1 ? 's' : ''} registered`;
    document.getElementById('my-events-results').style.display = 'block';

    switchTab('upcoming');
  } catch {
    showToast('Failed to load registrations.', 'error');
  }
}

// ── Tabs ──────────────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

  document.getElementById('tab-upcoming').classList.toggle('hidden', tab !== 'upcoming');
  document.getElementById('tab-past').classList.toggle('hidden',     tab !== 'past');

  const today    = new Date(); today.setHours(0,0,0,0);
  const upcoming = allRegistrations.filter(r => new Date(r.event_date + 'T00:00:00') >= today);
  const past     = allRegistrations.filter(r => new Date(r.event_date + 'T00:00:00') <  today);

  if (tab === 'upcoming') {
    document.getElementById('upcoming-list').innerHTML =
      upcoming.length ? upcoming.map(r => renderRegCard(r, false)).join('') : emptyTab('No upcoming events registered.');
  } else {
    document.getElementById('past-list').innerHTML =
      past.length ? past.map(r => renderRegCard(r, true)).join('') : emptyTab('No past events found.');
  }
}

function emptyTab(msg) {
  return `<div class="empty-state" style="padding:40px 24px">
    <div class="empty-state-icon">📭</div>
    <h3>${msg}</h3>
    <a href="/" class="btn btn-ghost mt-24">Browse Events</a>
  </div>`;
}

// ── Render Registration Card ──────────────────────────────────
function renderRegCard(reg, isPast) {
  const color = typeColor(reg.event_type);
  const hasFeedback = reg.feedback_rating;

  return `
  <div class="reg-event-card">
    <div class="reg-event-date" style="background:${color}">
      <div class="reg-event-date-day">${getDay(reg.event_date)}</div>
      <div class="reg-event-date-mon">${getMonthAbbr(reg.event_date)}</div>
    </div>
    <div class="reg-event-info">
      <div class="reg-event-title">${escHtml(reg.title)}</div>
      <div class="reg-event-sub">
        <span>🕐 ${formatTime(reg.event_time)}</span>
        <span>📍 ${escHtml(reg.venue)}</span>
        <span>🏢 ${escHtml(reg.department)}</span>
      </div>
      ${reg.speaker_name ? `<div style="font-size:.8rem;color:var(--text-muted);margin-top:4px">🎤 ${escHtml(reg.speaker_name)}</div>` : ''}
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;flex-shrink:0">
      <span class="badge" style="background:${color}20;color:${color};text-transform:capitalize">${reg.event_type}</span>
      ${isPast
        ? hasFeedback
          ? `<span class="badge badge-success">Rated ${reg.feedback_rating}★</span>`
          : `<button class="btn btn-ghost btn-sm" onclick="openFeedbackModal(${reg.event_id}, '${escHtml(reg.title).replace(/'/g,"\\'")}')">
               <i class="fa fa-star"></i> Rate Event
             </button>`
        : `<span class="badge badge-info" style="font-size:.7rem">
             Reg. ID: #${reg.id}
           </span>`
      }
    </div>
  </div>`;
}

function escHtml(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

// ── Feedback Modal ────────────────────────────────────────────
function openFeedbackModal(eventId, eventTitle) {
  feedbackRating = 0;
  document.getElementById('fb-event-id').value  = eventId;
  document.getElementById('feedback-event-name').textContent = eventTitle;
  document.getElementById('fb-comments').value  = '';
  document.getElementById('err-rating').classList.add('hidden');
  setRating(0);
  openModal('feedback-modal');
}

function closeFeedbackModal() { closeModalById('feedback-modal'); }

function setRating(val) {
  feedbackRating = val;
  document.querySelectorAll('#star-rating .star').forEach((s, i) => {
    s.classList.toggle('filled', i < val);
  });
}

async function submitFeedback() {
  if (!feedbackRating) {
    document.getElementById('err-rating').classList.remove('hidden');
    return;
  }

  const payload = {
    event_id:      parseInt(document.getElementById('fb-event-id').value),
    student_email: currentEmail,
    rating:        feedbackRating,
    comments:      document.getElementById('fb-comments').value.trim(),
  };

  try {
    const { data } = await apiFetch('/api/feedback', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });

    if (data.success) {
      showToast('Feedback submitted successfully!', 'success');
      closeFeedbackModal();
      lookupRegistrations(); // refresh
    } else {
      showToast(data.message || 'Failed to submit feedback.', 'error');
    }
  } catch {
    showToast('Failed to submit feedback.', 'error');
  }
}
