// routes/events.js — Event CRUD + search + stats
const express   = require('express');
const { body, query, param, validationResult } = require('express-validator');
const db        = require('../db');
const { requireAdmin } = require('../middleware/auth');
const router    = express.Router();

// ─── helpers ───────────────────────────────────────────────────────────────
const validate = validations => async (req, res, next) => {
  await Promise.all(validations.map(v => v.run(req)));
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};

// ──────────────────────────────────────────────────────────────────────────
// PUBLIC ROUTES (Student side)
// ──────────────────────────────────────────────────────────────────────────

/**
 * GET /api/events
 * Browse all upcoming active events with optional filters:
 *   ?department=CS&type=workshop&date=2024-12-01&search=AI&page=1&limit=9
 */
router.get('/', async (req, res, next) => {
  try {
    const {
      department, type, date, search,
      page = 1, limit = 9,
      upcoming = 'true',
    } = req.query;

    let where    = ['e.is_active = 1'];
    const params = [];

    if (upcoming === 'true') {
      where.push('e.event_date >= CURDATE()');
    }
    if (department) {
      where.push('e.department = ?');
      params.push(department);
    }
    if (type) {
      where.push('e.event_type = ?');
      params.push(type);
    }
    if (date) {
      where.push('e.event_date = ?');
      params.push(date);
    }
    if (search) {
      where.push('(e.title LIKE ? OR e.description LIKE ? OR e.speaker_name LIKE ?)');
      const q = `%${search}%`;
      params.push(q, q, q);
    }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset      = (parseInt(page) - 1) * parseInt(limit);

    // Total count for pagination
    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM events e ${whereClause}`,
      params
    );

    // Fetch events with registration count
    const [events] = await db.query(
      `SELECT 
         e.*,
         COUNT(r.id) AS registered_count,
         (e.max_seats - COUNT(r.id)) AS seats_available
       FROM events e
       LEFT JOIN registrations r ON r.event_id = e.id
       ${whereClause}
       GROUP BY e.id
       ORDER BY e.event_date ASC, e.event_time ASC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    res.json({
      success: true,
      data: events,
      pagination: {
        total,
        page:       parseInt(page),
        limit:      parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/events/types
 * Return distinct event types and departments for filter dropdowns
 */
router.get('/meta', async (req, res, next) => {
  try {
    const [departments] = await db.query(
      'SELECT DISTINCT department FROM events WHERE is_active = 1 ORDER BY department'
    );
    const [types] = await db.query(
      'SELECT DISTINCT event_type FROM events WHERE is_active = 1 ORDER BY event_type'
    );
    res.json({
      success: true,
      departments: departments.map(r => r.department),
      types:       types.map(r => r.event_type),
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/events/:id
 * Get single event detail
 */
router.get('/:id', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT 
         e.*,
         COUNT(r.id)            AS registered_count,
         (e.max_seats - COUNT(r.id)) AS seats_available,
         ROUND(AVG(f.rating),1) AS avg_rating,
         COUNT(DISTINCT f.id)   AS feedback_count
       FROM events e
       LEFT JOIN registrations r ON r.event_id = e.id
       LEFT JOIN feedback f      ON f.event_id = e.id
       WHERE e.id = ? AND e.is_active = 1
       GROUP BY e.id`,
      [req.params.id]
    );

    if (!rows.length) {
      const err = new Error('Event not found.');
      err.status = 404;
      return next(err);
    }

    res.json({ success: true, data: rows[0] });
  } catch (err) {
    next(err);
  }
});

// ──────────────────────────────────────────────────────────────────────────
// ADMIN ROUTES
// ──────────────────────────────────────────────────────────────────────────

/**
 * GET /api/events/admin/all
 * Get all events for admin (including past / inactive)
 */
router.get('/admin/all', requireAdmin, async (req, res, next) => {
  try {
    const { department, type, date, search, page = 1, limit = 10 } = req.query;

    let where    = [];
    const params = [];

    if (department) { where.push('e.department = ?');   params.push(department); }
    if (type)       { where.push('e.event_type = ?');   params.push(type); }
    if (date)       { where.push('e.event_date = ?');   params.push(date); }
    if (search) {
      where.push('(e.title LIKE ? OR e.description LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset      = (parseInt(page) - 1) * parseInt(limit);

    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) AS total FROM events e ${whereClause}`,
      params
    );

    const [events] = await db.query(
      `SELECT e.*, COUNT(r.id) AS registered_count
       FROM events e
       LEFT JOIN registrations r ON r.event_id = e.id
       ${whereClause}
       GROUP BY e.id
       ORDER BY e.event_date DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    res.json({
      success: true,
      data: events,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) },
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/events/admin/stats
 * Aggregate statistics for dashboard
 */
router.get('/admin/stats', requireAdmin, async (req, res, next) => {
  try {
    const [[summary]] = await db.query(`
      SELECT
        COUNT(DISTINCT e.id)                                    AS total_events,
        COUNT(DISTINCT CASE WHEN e.event_date >= CURDATE() AND e.is_active = 1 THEN e.id END) AS upcoming_events,
        COUNT(DISTINCT r.id)                                    AS total_registrations,
        COUNT(DISTINCT f.id)                                    AS total_feedback,
        ROUND(AVG(f.rating), 1)                                 AS avg_rating
      FROM events e
      LEFT JOIN registrations r ON r.event_id = e.id
      LEFT JOIN feedback f      ON f.event_id = e.id
    `);

    const [byType] = await db.query(`
      SELECT event_type, COUNT(*) AS count, SUM(registered_count) AS registrations
      FROM (
        SELECT e.event_type, COUNT(r.id) AS registered_count
        FROM events e
        LEFT JOIN registrations r ON r.event_id = e.id
        GROUP BY e.id
      ) t
      GROUP BY event_type
      ORDER BY registrations DESC
    `);

    const [byDept] = await db.query(`
      SELECT e.department, COUNT(DISTINCT e.id) AS events, COUNT(r.id) AS registrations
      FROM events e
      LEFT JOIN registrations r ON r.event_id = e.id
      GROUP BY e.department
      ORDER BY registrations DESC
      LIMIT 8
    `);

    const [topEvents] = await db.query(`
      SELECT e.id, e.title, e.event_date, e.event_type, COUNT(r.id) AS registrations
      FROM events e
      LEFT JOIN registrations r ON r.event_id = e.id
      GROUP BY e.id
      ORDER BY registrations DESC
      LIMIT 5
    `);

    res.json({ success: true, data: { summary, byType, byDept, topEvents } });
  } catch (err) {
    next(err);
  }
});

const eventValidation = [
  body('title').trim().notEmpty().withMessage('Title is required.').isLength({ max: 200 }),
  body('description').trim().notEmpty().withMessage('Description is required.'),
  body('event_date').isDate().withMessage('Valid date is required.'),
  body('event_time').matches(/^\d{2}:\d{2}(:\d{2})?$/).withMessage('Valid time (HH:MM) is required.'),
  body('venue').trim().notEmpty().withMessage('Venue is required.'),
  body('department').trim().notEmpty().withMessage('Department is required.'),
  body('event_type').isIn(['workshop','seminar','hackathon','cultural','sports','webinar','conference','other'])
    .withMessage('Invalid event type.'),
  body('max_seats').isInt({ min: 1 }).withMessage('Max seats must be a positive integer.'),
];

/**
 * POST /api/events
 * Create a new event (admin only)
 */
router.post('/', requireAdmin, validate(eventValidation), async (req, res, next) => {
  try {
    const { title, description, event_date, event_time, venue, department,
            event_type, max_seats, image_url, speaker_name, speaker_bio } = req.body;

    const [result] = await db.query(
      `INSERT INTO events 
         (title, description, event_date, event_time, venue, department, event_type,
          max_seats, image_url, speaker_name, speaker_bio, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [title, description, event_date, event_time, venue, department, event_type,
       max_seats, image_url || null, speaker_name || null, speaker_bio || null,
       req.session.admin.id]
    );

    res.status(201).json({ success: true, message: 'Event created successfully.', id: result.insertId });
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /api/events/:id
 * Update an event (admin only)
 */
router.put('/:id', requireAdmin, validate(eventValidation), async (req, res, next) => {
  try {
    const { title, description, event_date, event_time, venue, department,
            event_type, max_seats, image_url, speaker_name, speaker_bio, is_active } = req.body;

    const [result] = await db.query(
      `UPDATE events SET
         title=?, description=?, event_date=?, event_time=?, venue=?, department=?,
         event_type=?, max_seats=?, image_url=?, speaker_name=?, speaker_bio=?,
         is_active=?
       WHERE id=?`,
      [title, description, event_date, event_time, venue, department,
       event_type, max_seats, image_url || null, speaker_name || null, speaker_bio || null,
       is_active !== undefined ? is_active : 1, req.params.id]
    );

    if (result.affectedRows === 0) {
      const err = new Error('Event not found.'); err.status = 404; return next(err);
    }

    res.json({ success: true, message: 'Event updated successfully.' });
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/events/:id
 * Delete an event (admin only)
 */
router.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    const [result] = await db.query('DELETE FROM events WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) {
      const err = new Error('Event not found.'); err.status = 404; return next(err);
    }
    res.json({ success: true, message: 'Event deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
