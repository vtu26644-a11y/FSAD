// routes/registrations.js — Student registration + admin view
const express = require('express');
const { body, validationResult } = require('express-validator');
const db      = require('../db');
const { requireAdmin } = require('../middleware/auth');
const router  = express.Router();

// ──────────────────────────────────────────────────────────────────────────
// PUBLIC
// ──────────────────────────────────────────────────────────────────────────

/**
 * POST /api/registrations
 * Register a student for an event
 */
router.post(
  '/',
  [
    body('event_id').isInt({ min: 1 }).withMessage('Valid event is required.'),
    body('student_name').trim().notEmpty().withMessage('Name is required.')
      .isLength({ min: 2, max: 150 }).withMessage('Name must be 2–150 characters.'),
    body('student_email').isEmail().normalizeEmail().withMessage('Valid email is required.'),
    body('student_id').trim().notEmpty().withMessage('Student ID is required.'),
    body('department').trim().notEmpty().withMessage('Department is required.'),
    body('year_of_study').isInt({ min: 1, max: 5 }).withMessage('Year of study must be 1–5.'),
    body('phone').matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit Indian mobile number.'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { event_id, student_name, student_email, student_id, department, year_of_study, phone } = req.body;

    try {
      // Verify event exists and has seats
      const [[event]] = await db.query(
        `SELECT e.*, COUNT(r.id) AS registered_count
         FROM events e
         LEFT JOIN registrations r ON r.event_id = e.id
         WHERE e.id = ? AND e.is_active = 1 AND e.event_date >= CURDATE()
         GROUP BY e.id`,
        [event_id]
      );

      if (!event) {
        return res.status(404).json({ success: false, message: 'Event not found or registration is closed.' });
      }

      if (event.registered_count >= event.max_seats) {
        return res.status(409).json({ success: false, message: 'Sorry, this event is fully booked.' });
      }

      // Check duplicate
      const [[existing]] = await db.query(
        'SELECT id FROM registrations WHERE event_id = ? AND student_email = ?',
        [event_id, student_email]
      );

      if (existing) {
        return res.status(409).json({ success: false, message: 'You are already registered for this event.' });
      }

      const [result] = await db.query(
        `INSERT INTO registrations (event_id, student_name, student_email, student_id, department, year_of_study, phone)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [event_id, student_name, student_email, student_id, department, year_of_study, phone]
      );

      res.status(201).json({
        success:         true,
        message:         `You have successfully registered for "${event.title}".`,
        registration_id: result.insertId,
      });

    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/registrations/student/:email
 * Get all registrations by a student email
 */
router.get('/student/:email', async (req, res, next) => {
  try {
    const email = decodeURIComponent(req.params.email);
    const [rows] = await db.query(
      `SELECT r.*, e.title, e.event_date, e.event_time, e.venue, e.department,
              e.event_type, e.speaker_name,
              f.rating AS feedback_rating, f.comments AS feedback_comments
       FROM registrations r
       JOIN events e ON e.id = r.event_id
       LEFT JOIN feedback f ON f.event_id = r.event_id AND f.student_email = r.student_email
       WHERE r.student_email = ?
       ORDER BY e.event_date DESC`,
      [email]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/registrations/:id
 * Cancel own registration (student cancels)
 */
router.delete('/:id', async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email required to cancel registration.' });
    }

    const [result] = await db.query(
      'DELETE FROM registrations WHERE id = ? AND student_email = ?',
      [req.params.id, email]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Registration not found or email mismatch.' });
    }

    res.json({ success: true, message: 'Registration cancelled successfully.' });
  } catch (err) {
    next(err);
  }
});

// ──────────────────────────────────────────────────────────────────────────
// ADMIN ROUTES
// ──────────────────────────────────────────────────────────────────────────

/**
 * GET /api/registrations/event/:eventId
 * Get all registrations for a specific event (admin)
 */
router.get('/event/:eventId', requireAdmin, async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT r.*, e.title AS event_title
       FROM registrations r
       JOIN events e ON e.id = r.event_id
       WHERE r.event_id = ?
       ORDER BY r.registered_at DESC`,
      [req.params.eventId]
    );
    res.json({ success: true, data: rows, count: rows.length });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
