// routes/feedback.js — Student feedback submission + admin view
const express = require('express');
const { body, validationResult } = require('express-validator');
const db      = require('../db');
const { requireAdmin } = require('../middleware/auth');
const router  = express.Router();

/**
 * POST /api/feedback
 * Submit feedback for a past event
 */
router.post(
  '/',
  [
    body('event_id').isInt({ min: 1 }).withMessage('Valid event ID required.'),
    body('student_email').isEmail().normalizeEmail().withMessage('Valid email is required.'),
    body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5.'),
    body('comments').optional().trim().isLength({ max: 1000 }).withMessage('Comments must be under 1000 characters.'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { event_id, student_email, rating, comments } = req.body;

    try {
      // Verify the student was registered
      const [[reg]] = await db.query(
        'SELECT id FROM registrations WHERE event_id = ? AND student_email = ?',
        [event_id, student_email]
      );

      if (!reg) {
        return res.status(403).json({
          success: false,
          message: 'You must be a registered attendee to submit feedback.',
        });
      }

      // Verify event is in the past
      const [[event]] = await db.query(
        'SELECT id, title FROM events WHERE id = ? AND event_date < CURDATE()',
        [event_id]
      );

      if (!event) {
        return res.status(400).json({
          success: false,
          message: 'Feedback can only be submitted for events that have already taken place.',
        });
      }

      await db.query(
        `INSERT INTO feedback (event_id, student_email, rating, comments)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE rating = VALUES(rating), comments = VALUES(comments)`,
        [event_id, student_email, rating, comments || null]
      );

      res.status(201).json({ success: true, message: 'Thank you for your feedback!' });

    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/feedback/event/:eventId
 * Get all feedback for an event
 */
router.get('/event/:eventId', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT f.rating, f.comments, f.submitted_at,
              CONCAT(LEFT(r.student_name, 1), '***') AS student_name_masked
       FROM feedback f
       JOIN registrations r ON r.event_id = f.event_id AND r.student_email = f.student_email
       WHERE f.event_id = ?
       ORDER BY f.submitted_at DESC`,
      [req.params.eventId]
    );

    const [[stats]] = await db.query(
      `SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS total_reviews,
              SUM(rating=5) AS r5, SUM(rating=4) AS r4, SUM(rating=3) AS r3,
              SUM(rating=2) AS r2, SUM(rating=1) AS r1
       FROM feedback WHERE event_id = ?`,
      [req.params.eventId]
    );

    res.json({ success: true, data: rows, stats });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/feedback/admin/all
 * All feedback (admin)
 */
router.get('/admin/all', requireAdmin, async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT f.*, e.title AS event_title, r.student_name
       FROM feedback f
       JOIN events e ON e.id = f.event_id
       JOIN registrations r ON r.event_id = f.event_id AND r.student_email = f.student_email
       ORDER BY f.submitted_at DESC
       LIMIT 100`
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
